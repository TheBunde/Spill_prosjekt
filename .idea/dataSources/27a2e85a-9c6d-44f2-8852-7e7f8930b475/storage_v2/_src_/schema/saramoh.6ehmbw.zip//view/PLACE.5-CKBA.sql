create view PLACE as
select `saramoh`.`levinfo`.`levby` AS `levby`, `saramoh`.`levinfo`.`fylke` AS `fylke`
from `saramoh`.`levinfo`;

