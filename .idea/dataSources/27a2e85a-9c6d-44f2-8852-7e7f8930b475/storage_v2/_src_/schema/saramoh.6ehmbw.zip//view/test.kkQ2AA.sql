create view test as (select distinct `saramoh`.`prisinfo`.`levnr`      AS `levnr`,
                                     `saramoh`.`prisinfo`.`delnr`      AS `delnr`,
                                     `saramoh`.`ordredetalj`.`kvantum` AS `kvantum`,
                                     `saramoh`.`prisinfo`.`pris`       AS `pris`
                     from (`saramoh`.`prisinfo`
                            left join `saramoh`.`ordredetalj`
                                      on ((`saramoh`.`prisinfo`.`delnr` = `saramoh`.`ordredetalj`.`delnr`)))
                     where (`saramoh`.`ordredetalj`.`ordrenr` = 18));

