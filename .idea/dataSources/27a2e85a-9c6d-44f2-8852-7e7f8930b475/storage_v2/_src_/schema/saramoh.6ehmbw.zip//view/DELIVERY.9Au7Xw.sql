create view DELIVERY as
select `saramoh`.`levinfo`.`levnr`   AS `levnr`,
       `saramoh`.`levinfo`.`navn`    AS `navn`,
       `saramoh`.`levinfo`.`adresse` AS `adresse`,
       `saramoh`.`levinfo`.`levby`   AS `levby`,
       `saramoh`.`levinfo`.`postnr`  AS `postnr`
from `saramoh`.`levinfo`;

