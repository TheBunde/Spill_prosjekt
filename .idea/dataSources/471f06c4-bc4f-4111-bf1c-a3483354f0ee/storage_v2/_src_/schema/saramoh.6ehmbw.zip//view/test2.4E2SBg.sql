create definer = saramoh@`%` view test2 as (select `test`.`levnr` AS `levnr`, count(`test`.`levnr`) AS `antall_del`
                                            from `saramoh`.`test`
                                            group by `test`.`levnr`
                                            having (count(`test`.`levnr`) > 1));

