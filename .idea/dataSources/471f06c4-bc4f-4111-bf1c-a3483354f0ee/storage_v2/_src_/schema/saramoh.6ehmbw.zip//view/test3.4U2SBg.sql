create definer = saramoh@`%` view test3 as (select `saramoh`.`forfatter`.`fode_aar`                                     AS `fode_aar`,
                                                   `saramoh`.`forfatter`.`dod_aar`                                      AS `dod_aar`,
                                                   (`saramoh`.`forfatter`.`dod_aar` - `saramoh`.`forfatter`.`fode_aar`) AS `age`
                                            from `saramoh`.`forfatter`
                                            where (`saramoh`.`forfatter`.`dod_aar` is not null))
                                           union
                                           (select `saramoh`.`forfatter`.`fode_aar`                     AS `fode_aar`,
                                                   `saramoh`.`forfatter`.`dod_aar`                      AS `dod_aar`,
                                                   (year(curdate()) - `saramoh`.`forfatter`.`fode_aar`) AS `(YEAR(CURRENT_DATE) - fode_aar)`
                                            from `saramoh`.`forfatter`
                                            where (isnull(`saramoh`.`forfatter`.`dod_aar`) and
                                                   (`saramoh`.`forfatter`.`fode_aar` > 1900)));

