create definer = saramoh@`%` view tabell2 as (select `saramoh`.`bestilling`.`modell_navn`        AS `modell_navn`,
                                                     count(`saramoh`.`bestilling`.`modell_navn`) AS `antall`,
                                                     sum(`saramoh`.`bestilling`.`ant_stol`)      AS `sum`
                                              from `saramoh`.`bestilling`
                                              group by `saramoh`.`bestilling`.`modell_navn`);

