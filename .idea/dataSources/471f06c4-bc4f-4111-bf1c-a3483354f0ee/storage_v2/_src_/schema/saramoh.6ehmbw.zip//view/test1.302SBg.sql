create definer = saramoh@`%` view test1 as (select distinct `test2`.`levnr`  AS `levnr`,
                                                            `test`.`delnr`   AS `delnr`,
                                                            `test`.`kvantum` AS `kvantum`,
                                                            `test`.`pris`    AS `pris`
                                            from (`saramoh`.`test2`
                                                   left join `saramoh`.`test` on ((`test`.`levnr` = `test2`.`levnr`))));

