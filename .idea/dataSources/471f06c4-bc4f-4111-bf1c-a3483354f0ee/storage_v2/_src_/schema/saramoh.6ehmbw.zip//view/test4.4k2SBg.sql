create definer = saramoh@`%` view test4 as (select `test1`.`levnr`                      AS `levnr`,
                                                   `test1`.`delnr`                      AS `delnr`,
                                                   `test1`.`kvantum`                    AS `kvantum`,
                                                   `test1`.`pris`                       AS `pris`,
                                                   (`test1`.`kvantum` * `test1`.`pris`) AS `beregnet_pirs`
                                            from `saramoh`.`test1`);

